	//儲存資料
	function save(d){
        var db = openDatabase('109-506','18.4','local database demo',2 * 1024 * 1024);
        var user_name_f_0 = d.getElementById(id).value;
        //建立時間
        var time = new Date().getTime();
        db.transaction(function(tx){
        tx.executeSql('insert into contact values(?,?,?,?)',[user_name_f_0,time],onSuccess,onError);
        });
        }
        //sql語句執行成功後執行的回撥函式
        function onSuccess(tx,rs){
        alert("操作成功");
        loadAll();
        location.href = "main.html";
        }
        //sql語句執行失敗後執行的回撥函式
        function onError(tx,error){
        alert("操作失敗,失敗資訊:"+ error.message);  
        }