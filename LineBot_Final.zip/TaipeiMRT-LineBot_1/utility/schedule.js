'use strict';

//引用操作資料庫的物件
const query = require('./asyncDB');

//-------------------
// 查看排程使用情形
//-------------------
var searchScheduleUsed = async function(Id){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT a.schedule_id,b.schedule_route_id,b.sta_id FROM schedule AS a Join schedule_route As b ON a.schedule_id = b.schedule_id WHERE member_account = $1 AND sta_id IS NULL ORDER BY b.schedule_route_id DESC',[Id])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查詢排程編號
//-------------------
var searchScheduleId = async function(Id){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT a.schedule_id,b.schedule_route_id FROM schedule AS a JOIN schedule_route AS b ON a.schedule_id = b.schedule_id WHERE a.member_account = $1 ORDER BY schedule_route_id DESC',[Id])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}



//-------------------
// 查看排程內容
//-------------------
var searchSchedule = async function(){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule_route ORDER BY schedule_route_id DESC')
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 新增排程資料(schedule資料表)
//-------------------
var addSchedule = async function(sId,mId){
    //存放結果
    let result;
    //寫入資料表
    await query('INSERT INTO schedule(schedule_id,member_account) VALUES ($1,$2)', [sId,mId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });
        console.log(result);

    //回傳執行結果
    return result;
}

//-------------------
// 新增排程資料(schedule_route資料表)
//-------------------
var addScheduleRoute = async function(rId,sId){
    //存放結果
    let result;
    //寫入資料表
    await query('INSERT INTO schedule_route(schedule_route_id,schedule_id) VALUES ($1,$2)', [rId,sId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 新增排程詳細資料(schedule_route資料表)
//-------------------
var updateScheduleRoute = async function(rId,array,staId){
    //存放結果
    let result;
    //寫入資料表
    await query('UPDATE schedule_route SET schedule_route_array = $2,sta_id = $3 WHERE schedule_route_id = $1', [rId,array,staId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 新增排程美食資料(schedule_route_detail資料表)
//-------------------
var addScheduleRouteDetailsFood = async function(sId,array,foodId,type){
    //存放結果
    let result;
    //寫入資料表
    await query('INSERT INTO schedule_route_detail(schedule_id,detail_array,food_id,detail_type) VALUES ($1,$2,$3,$4)', [sId,array,foodId,type])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 新增排程景點資料
//-------------------
var addScheduleRouteDetailsAtt = async function(sId,array,attId,type){
    //存放結果
    let result;
    //寫入資料表
    await query('INSERT INTO schedule_route_detail(schedule_id,detail_array,att_id,detail_type) VALUES ($1,$2,$3,$4)', [sId,array,attId,type])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 查看排程車站資料
//-------------------
var scheduleInfo = async function(sId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule_route As a Join station AS b ON a.sta_id = b.sta_id JOIN route AS c ON b.route_id = c.route_id WHERE schedule_id = $1 ORDER BY schedule_route_array',[sId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看排程美食資料
//-------------------
var scheduleDetailsFoodInfo = async function(sId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule_route_detail AS a JOIN food AS b ON a.food_id = b.food_id JOIN mrt_exit AS c ON b.exit_id = c.exit_id JOIN station AS d ON c.sta_id = d.sta_id JOIN route as e ON d.route_id = e.route_id WHERE schedule_id = $1 ORDER BY schedule_id',[sId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
} 

//-------------------
// 查看排程景點資料
//-------------------
var scheduleDetailsAttInfo = async function(sId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule_route_detail AS a JOIN attractions AS b ON a.att_id = b.att_id JOIN mrt_exit AS c ON b.exit_id = c.exit_id JOIN station AS d ON c.sta_id = d.sta_id JOIN route AS e ON d.route_id = e.route_id WHERE schedule_id = $1 ORDER BY schedule_id',[sId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看美食景點順序資訊
//-------------------
var scheduleDetailsArray = async function(sId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule_route_detail WHERE schedule_id = $1',[sId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 新增排程日期
//-------------------
var updateScheduleDate = async function(sDate,sId){
    //存放結果
    let result;
    //寫入資料表
    await query('UPDATE schedule SET schedule_time = $1 WHERE schedule_id = $2', [sDate,sId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 新增排程名稱
//-------------------
var updateSchedule = async function(sName,sId){
    //存放結果
    let result;
    //寫入資料表
    await query('UPDATE schedule SET schedule_name = $1 WHERE schedule_id = $2', [sName,sId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 查看排程資訊(schedule資料表)
//-------------------
var searchScheduleById = async function(id){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule WHERE member_account = $1 AND schedule_name IS NOT NULL ORDER BY schedule_id DESC',[id])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看排程資訊(schedule_route資料表)
//-------------------
var searchScheduleInfoBysId = async function(sId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM schedule_route AS a JOIN station AS b ON a.sta_id = b.sta_id JOIN route AS c ON b.route_id = c.route_id WHERE schedule_id = $1 ORDER BY schedule_route_array',[sId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 更新排程資訊(schedule_route資料表)
//-------------------
var deleteScheduleRoute = async function(sId){
    //存放結果
    let result;
    //寫入資料表
    await query('DELETE FROM schedule_route WHERE schedule_id = ($1)', [sId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });

    //回傳執行結果
    return result;
}

//-------------------
// 更新排程資訊(schedule資料表)
//-------------------
var deleteSchedule = async function(sId){
    //存放結果
    let result;
    //寫入資料表
    await query('UPDATE schedule SET schedule_name = Null WHERE schedule_id = $1', [sId])
        .then((data) => {
            result = 0;   //寫入成功
        }, (error) => {
            result = -9;  //寫入錯誤
        });
        console.log(result);
    //回傳執行結果
    return result;
}


//-----------------------
// 匯出函式
//-----------------------
module.exports = {searchScheduleUsed,searchScheduleId,searchSchedule,addSchedule,addScheduleRoute,updateScheduleRoute,addScheduleRouteDetailsFood,addScheduleRouteDetailsAtt,scheduleInfo,scheduleDetailsFoodInfo,scheduleDetailsAttInfo,scheduleDetailsArray,updateScheduleDate,updateSchedule,searchScheduleById,searchScheduleInfoBysId,deleteScheduleRoute,deleteSchedule};