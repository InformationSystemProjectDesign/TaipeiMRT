'use strict';

//引用操作資料庫的物件
const query = require('./asyncDB');

//-------------------
// 查看
//-------------------
var listAStationCategory = async function(routeId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM station WHERE route_id = $1 ORDER BY sta_id',[routeId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看
//-------------------
var searchStationName = async function(staId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM route JOIN station ON route.route_id = station.route_id WHERE sta_id = $1',[staId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看
//-------------------
var searchScheduleStationName = async function(sId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT sta_name FROM schedule_route AS a JOIN station AS b ON a.sta_id = b.sta_id WHERE schedule_id = $1 ORDER BY schedule_route_id DESC',[sId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}




//-----------------------
// 匯出函式
//-----------------------
module.exports = {listAStationCategory,searchStationName,searchScheduleStationName};