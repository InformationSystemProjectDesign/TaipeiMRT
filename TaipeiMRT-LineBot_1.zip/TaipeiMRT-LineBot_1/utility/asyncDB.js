'use strict';

//-----------------------
// 引用資料庫模組
//-----------------------
const {Client} = require('pg');

//-----------------------
// 自己的資料庫連結位址
//-----------------------
var pgConn = 'postgres://seuuuplrvwsfbi:b47d1aa8467e43fd070ef24fe82ddc1479e7c00caa4974b5478de6fe8aeee5e5@ec2-34-225-82-212.compute-1.amazonaws.com:5432/ddhbf9d4bi4ap';

//產生可同步執行query物件的函式
function query(sql, value=null) {
    return new Promise((resolve, reject) => {
        //設定資料庫連線物件
        var client = new Client({
            connectionString: pgConn,
            ssl: true
        })     

        //連結資料庫
        client.connect();

        //回覆查詢結果  
        client.query(sql, value, (err, results) => {                   
            if (err){
                reject(err);
            }else{
                resolve(results);
            }

            //關閉連線
            client.end();
        });
    });
}

//-----------------------
// 匯出函式
//-----------------------
module.exports = query;