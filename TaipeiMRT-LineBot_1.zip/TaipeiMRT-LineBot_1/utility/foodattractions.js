'use strict';

//引用操作資料庫的物件
const query = require('./asyncDB');

//-------------------
// 查看
//-------------------
var searchFAUsed = async function(sId,id){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT a.schedule_time,b.schedule_route_id,b.sta_id FROM schedule AS a Join schedule_route As b ON a.schedule_id = b.schedule_id WHERE a.schedule_id = $1 AND member_account = $2 AND schedule_time IS NULL ORDER BY b.schedule_route_id DESC',[sId,id])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看
//-------------------
var listAFoodRecommand = async function(){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT a.food_id,b.food_name,b.food_pic,COUNT(a.food_id) FROM "schedule_route_detail" as a JOIN "food" as b On a.food_id = b.food_id WHERE a.food_id IS NOT NULL GROUP BY a.food_id,b.food_name,b.food_pic ORDER BY COUNT(a.food_id) DESC Limit 10')
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看
//-------------------
var listAAttractionsRecommand = async function(){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT a.att_id,b.att_name,b.att_pic,COUNT(a.att_id) FROM "schedule_route_detail" AS a JOIN "attractions" AS b ON a.att_id = b.att_id WHERE a.att_id IS NOT NULL GROUP BY a.att_id,b.att_name,b.att_pic ORDER BY COUNT(a.att_id) DESC LIMIT 10')
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看
//-------------------
var listAFoodCategory = async function(foodId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM food WHERE food_name LIKE $1',[foodId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-------------------
// 查看
//-------------------
var listAAttractionsCategory = async function(attId){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM attractions WHERE att_name LIKE $1',[attId])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

var listFoodDetails = async function(id){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM food JOIN mrt_exit ON mrt_exit.exit_id = food.exit_id JOIN station ON station.sta_id = mrt_exit.sta_id JOIN route ON route.route_id = station.route_id WHERE food_id  = $1',[id])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

var listAttractionsDetails = async function(id){
    //存放結果
    let result; 

    //讀取資料庫
    await query('SELECT * FROM attractions JOIN mrt_exit ON mrt_exit.exit_id = attractions.exit_id JOIN station ON station.sta_id = mrt_exit.sta_id JOIN route ON route.route_id = station.route_id WHERE att_id  = $1',[id])
        .then((data) => {
            result = data.rows;   //查詢成功
        }, (error) => {
            result = -9;     //查詢失敗
        });

    //回傳執行結果
    return result;  
}

//-----------------------
// 匯出函式
//-----------------------
module.exports = {searchFAUsed,listAFoodRecommand,listAAttractionsRecommand,listAFoodCategory, listAAttractionsCategory,listFoodDetails,listAttractionsDetails};